# Software) 사용 중 코드 전체 공유 - door_test.py

날짜: 2024년 11월 10일

### door_test.py - 도어락 테스트 예제

```java
import RPi.GPIO as GPIO
import time

DOOR_PIN = 17
#DOOR_PIN2 = 18
GPIO.setmode(GPIO.BCM)
GPIO.setup(DOOR_PIN, GPIO.OUT)

def unlock_door():
   GPIO.output(DOOR_PIN, GPIO.HIGH)
   print("open")
   time.sleep(5)
   GPIO.output(DOOR_PIN, GPIO.LOW)

try:
   unlock_door()
finally:
   GPIO.cleanup()
```